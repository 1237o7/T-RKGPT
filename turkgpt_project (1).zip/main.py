from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from transformers import AutoTokenizer, AutoModelForCausalLM
import uvicorn

model_name = "tiiuae/falcon-rw-1b"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
async def index():
    return '''
    <!DOCTYPE html><html lang='tr'><head><meta charset='UTF-8'>
    <script src='https://cdn.tailwindcss.com'></script><title>TürkGPT</title></head>
    <body class='bg-gray-100 flex justify-center items-center min-h-screen'>
    <div class='max-w-xl w-full bg-white p-8 rounded shadow'>
    <h1 class='text-2xl font-bold text-blue-600 text-center mb-4'>TürkGPT</h1>
    <textarea id='prompt' rows='4' class='w-full p-3 border rounded' placeholder='Yaz...'></textarea>
    <button onclick='sendPrompt()' class='bg-blue-500 text-white px-4 py-2 mt-3 rounded hover:bg-blue-600'>Gönder</button>
    <pre id='response' class='mt-4 bg-gray-200 p-3 rounded text-sm whitespace-pre-wrap'></pre>
    </div><script>
    async function sendPrompt(){const p=document.getElementById('prompt').value;
    const r=await fetch('/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:p})});
    const d=await r.json();document.getElementById('response').innerText=d.response;}
    </script></body></html>
    '''

@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    prompt = data.get("prompt", "")
    inputs = tokenizer(prompt, return_tensors="pt")
    outputs = model.generate(**inputs, max_new_tokens=100)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return {"response": response}
